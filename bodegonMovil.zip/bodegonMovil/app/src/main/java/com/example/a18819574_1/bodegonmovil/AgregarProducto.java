package com.example.a18819574_1.bodegonmovil;

import android.os.Bundle;
import android.app.Activity;

public class AgregarProducto extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_producto);
    }

}
