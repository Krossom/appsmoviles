package com.example.a18819574_1.bodegonmovil;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edtRut, edtContra;
    Button btnOlvido, btnIngresar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Ingresar(View v){
        Intent ingreso = new Intent(this,Menu.class);
        //ingreso.putExtra("dato", edtRut.getText().toString());
        //ingreso.putExtra("dato2", edtContra.getText().toString());
        startActivity(ingreso);
    }


}
