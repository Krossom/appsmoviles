package com.example.a18819574_1.bodegonmovil;

import android.support.v7.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
    /*
    public void Agregar{

    }
    public void Mostrar{

    }
    public void Modificar{

    }*/
}
